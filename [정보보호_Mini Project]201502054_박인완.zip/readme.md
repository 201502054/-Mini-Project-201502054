#201502054_박인완 보안과제

## 사용법
####connect: 연결 -> id 입력해줘야함
####disconnect: 연결종료 
####exchange:키교환 -> 누구랑 키 교환할지 입력해줘야함
####re_exchange:대칭키 변경하고싶을때
####message:메시지 보낼때
####connect -> exchange -> message 순으로 사용

##사용한 라이브러리
###pycryptodome


##참고
#####pycryptodome get_random_bytes()메소드를 이용해 256비트대칭키, 128비트 iv를 생성했습니다.
#####RSA 공개키를 이용해 대칭키를 암호화하였고, RSA 개인키를 이용해서 키를 복호화하였습니다.
####pycryptodome  RSA.generate()메소드를 이용해 공개키, 비밀키를 생성했습니다.


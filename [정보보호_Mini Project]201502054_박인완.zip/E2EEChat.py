import socket
import threading
# 추가한부분
from base64 import b64encode, b64decode
from Crypto.PublicKey import RSA
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.Random import get_random_bytes
import mypayload

# 서버 연결정보; 자체 서버 실행시 변경 가능
SERVER_HOST = "homework.islab.work"
SERVER_PORT = 8080

connectSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
connectSocket.connect((SERVER_HOST, SERVER_PORT))

# 추가한부분
MY_ID = ""
OPPONENT_ID = ""
KEY = ""
IV = ""
isSend = False


#########

def socket_read():
    while True:
        readbuff = connectSocket.recv(2048)

        if len(readbuff) == 0:
            continue

        recv_payload = readbuff.decode('utf-8')
        parse_payload(recv_payload)



def socket_send():
    while True:

        str = input("METHOD: ")

        # connect: 연결, disconnect: 연결종료, exchange:키교환, re_exchange:대칭키 변경하고싶을때, message:메시지 보낼때
        if str == 'connect':
            send_bytes = Connect_server()

        elif str == 'disconnect':
            send_bytes = Disconnect_server()

        elif str == 'exchange':
            send_bytes = Key_exchange()

        elif str == 're_exchange':
            send_bytes = Key_re_exchange()

        elif str == 'message':
            send_bytes = Message_send()

        else:
            print('알 수 없는 명령어입니다.')
            continue

        connectSocket.sendall(send_bytes)


# 수신된 페이로드를 여기서 처리; 필요할 경우 추가 함수 정의 가능
def parse_payload(payload):
    global KEY
    global IV
    global OPPONENT_ID
    global isSend

    split_payload = payload.split('\n')

    Blank = split_payload[0].find(' ')
    Method = split_payload[0][Blank+1:]


    if (Method == "KEYXCHG" and KEY == "") or Method == "KEYXCHGRST":

        # base64로 인코딩되어있던 키와 iv를 디코딩
        enc_KEY = b64decode(split_payload[-2].encode('utf-8'))
        IV = b64decode(split_payload[-1].encode('utf-8'))

        # 개인키로 암호화되어있던 대칭키 복원
        private_key = RSA.import_key(open("private_key.pem").read())
        cipher_rsa = PKCS1_OAEP.new(private_key)
        KEY = cipher_rsa.decrypt(enc_KEY)

        # print('수신한 KEY: ', KEY)
        # print('수신한 IV: ', IV)

        for split in split_payload:
            if "From" in split:
                OPPONENT_ID = split[split.find(':') + 1:]

        Key_exchangeOK(OPPONENT_ID)

    elif Method == "KEYXCHG" and KEY != "":
        Key_Duplicated()

    elif Method == "MSGRECV":
        # print("작동")
        # print('split_payload 출력: ', split_payload)

        # 메시지는 base64로 인코딩되어있으므로, base64로 디코딩함
        message = split_payload[-1].encode('utf-8')
        message = b64decode(message)

        # Decrypt 메소드를 통해서 암호화 해제
        plaintext = Decrypt(message)

        # 메시지 바이트 끝부분을 확인해서 패딩이 얼마나됐는지를 확인
        padding_len = plaintext[-1]

        # 0일경우는 16개만큼 패딩됐으므로, 그만큼 적게읽고, 아니면 패딩된 길이만큼 적게읽음
        if padding_len == 0:
            plaintext = plaintext[:-16]
        else:
            plaintext = plaintext[:-padding_len]

        # 암호화된 메시지를, 해독된 메시지로 변경
        split_payload[-1] = plaintext.decode('utf-8')

        payload = ''

        for split in split_payload:
            payload += split + '\n'

    print(payload)


# 추가한부분
def PKCS_padding(text):
    # PKCS: 비어있는 바이트 수 만큼 해당 값으로 채우기

    # pycryptodome CBC모드가 16바이트 단위로 블록을 보내서, 패딩을 그만큼 해주었습니다.
    remainder = len(text) % 16  # 나머지

    padding_text = bytearray(16 - remainder)  # 패딩할 바이트배열
    padding_len = len(padding_text)  # 길이

    for i in range(padding_len):
        padding_text[i] = padding_len  # 패딩한 길이만큼 그 값을 다 채움

    padding_text = text + padding_text

    return padding_text


def Encrypt(plaintext):
    global KEY
    global IV

    # 평문을 PKCS_padding 메소드를 이용해 패딩
    padding_text = PKCS_padding(plaintext)

    # 패딩한 평문을 AES_CBC모드로 암호화
    cipher = AES.new(key=KEY, mode=AES.MODE_CBC, iv=IV)
    ciphertext = cipher.encrypt(padding_text)

    return ciphertext


def Decrypt(ciphertext):
    global KEY
    global IV

    # 암호문을 암호화 해제 후 평문으로 반환
    cipher = AES.new(key=KEY, mode=AES.MODE_CBC, iv=IV)
    plaintext = cipher.decrypt(ciphertext)

    return plaintext


# 서버 연결하는 페이로드를 반환하는 메소드
def Connect_server():
    global MY_ID
    preamble = mypayload.preamble('CONNECT')
    MY_ID = input('Enter id:')
    header = mypayload.header('Credential', MY_ID)

    return preamble + header


# 서버 연결 해제하는 페이로드를 반환하는 메소드
def Disconnect_server():
    preamble = mypayload.preamble('DISCONNECT')
    header = mypayload.header('Credential', MY_ID)

    return preamble + header


# 키를 교환하는 페이로드를 반환하는 메소드
def Key_exchange():
    global KEY
    global IV
    global OPPONENT_ID

    # 대칭키
    KEY = get_random_bytes(32)
    IV = get_random_bytes(16)

    # print('송신한 KEY: ', KEY)
    # print('송신한 IV: ', IV)

    # 대칭키를 RSA공개키로 암호화
    recipient_key = RSA.import_key(open("public_key.pem").read())
    cipher_rsa = PKCS1_OAEP.new(recipient_key)
    enc_KEY = cipher_rsa.encrypt(KEY)

    # base64로 인코딩
    enc_KEY = b64encode(enc_KEY)
    enc_IV = b64encode(IV)

    preamble = mypayload.preamble('KEYXCHG')
    header1 = mypayload.header('Algo', 'AES-256-CBC')
    header2 = mypayload.header('From', MY_ID)

    OPPONENT_ID = input('To: ')
    header3 = mypayload.header('To', OPPONENT_ID)

    return preamble + header1 + b'\n' + header2 + b'\n' + header3 + b'\n' + b'\n' + enc_KEY + b'\n' + enc_IV


# 키 재교환
def Key_re_exchange():
    global KEY
    global IV
    global OPPONENT_ID

    # 대칭키
    KEY = get_random_bytes(32)
    IV = get_random_bytes(16)

    # print('송신한 KEY: ', KEY)
    # print('송신한 IV: ', IV)

    # 대칭키를 RSA공개키로 암호화
    recipient_key = RSA.import_key(open("public_key.pem").read())
    cipher_rsa = PKCS1_OAEP.new(recipient_key)
    enc_KEY = cipher_rsa.encrypt(KEY)

    # base64로 인코딩
    enc_KEY = b64encode(enc_KEY)
    enc_IV = b64encode(IV)

    preamble = mypayload.preamble('KEYXCHGRST')
    header1 = mypayload.header('Algo', 'AES-256-CBC')
    header2 = mypayload.header('From', MY_ID)
    header3 = mypayload.header('To', OPPONENT_ID)

    return preamble + header1 + b'\n' + header2 + b'\n' + header3 + b'\n' + b'\n' + enc_KEY + b'\n' + enc_IV


# 키 교환이 잘됐다고 보내는 페이로드를 반환하는 메소드
def Key_exchangeOK(OPPONENT_ID):
    preamble = mypayload.preamble('KEYXCHGOK')
    header1 = mypayload.header('Algo', 'AES-256-CBC')
    header2 = mypayload.header('From', MY_ID)
    header3 = mypayload.header('To', OPPONENT_ID)

    send_bytes = preamble + header1 + b'\n' + header2 + b'\n' + header3

    connectSocket.send(send_bytes)


# 키 중복
def Key_Duplicated():
    preamble = mypayload.preamble('KEYXCHGFAIL')
    header1 = mypayload.header('Algo', 'AES-256-CBC')
    header2 = mypayload.header('From', MY_ID)
    header3 = mypayload.header('To', OPPONENT_ID)
    body = b'Duplicated Key Exchange Request'

    send_bytes = preamble + header1 + b'\n' + header2 + b'\n' + header3 + b'\n' + b'\n' + body
    connectSocket.send(send_bytes)


# 메시지 전송
def Message_send():
    My_message = input("MESSAGE: ")
    ciphertext = Encrypt(My_message.encode('utf-8'))

    nonce = get_random_bytes(12)  # 96비트 nonce
    nonce = b64encode(nonce).decode('utf-8')

    preamble = mypayload.preamble('MSGSEND')
    header1 = mypayload.header('From', MY_ID)
    header2 = mypayload.header('To', OPPONENT_ID)
    header3 = mypayload.header('nonce', nonce)

    # base64로 인코딩
    body = b64encode(ciphertext)

    return preamble + header1 + b'\n' + header2 + b'\n' + header3 + b'\n' + b'\n' + body


if __name__ == '__main__':
    reading_thread = threading.Thread(target=socket_read)
    sending_thread = threading.Thread(target=socket_send)

    reading_thread.start()
    sending_thread.start()

    reading_thread.join()
    sending_thread.join()
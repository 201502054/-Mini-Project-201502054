from Crypto.PublicKey import RSA
#대칭키를 암호화하기위해 키 생성

key = RSA.generate(2048)
private_key = key.export_key()

#개인키 생성
f = open('private_key.pem','wb')
f.write(private_key)
f.close()

#공개키 생성
public_key = key.public_key().export_key()
f = open('public_key.pem','wb')
f.write(public_key)
f.close()

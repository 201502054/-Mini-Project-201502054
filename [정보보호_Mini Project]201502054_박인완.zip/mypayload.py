def preamble(method):
    preamble = '3EPROTO ' + method + '\n'
    preamble = preamble.encode('utf-8')

    return preamble


def header(key, value):
    header = key + ":" + value
    header = header.encode('utf-8')

    return header

